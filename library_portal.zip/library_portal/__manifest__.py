{
    'name': 'Library Portal',
    'version': '1.0',
    'summary': 'Library Portal for Book Borrowing',
    'author': 'Your Name',
    'category': 'Website',
    'depends': ['base', 'web', 'website'],
    'data': [
        'security/ir.model.access.csv',
        'views/backend_views.xml',
        'views/templates.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
