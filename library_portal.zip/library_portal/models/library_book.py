from odoo import models, fields

class LibraryBook(models.Model):
    _name = 'library.book'
    _description = 'Library Book'

    name = fields.Char(string='Title', required=True)
    author = fields.Char(string='Author')
    isbn = fields.Char(string='ISBN')
    quantity = fields.Integer(string='Quantity Available', default=1)
    description = fields.Text(string='Description')
    image = fields.Binary(string='Cover Image')
    state = fields.Selection([
        ('available', 'Available'),
        ('out_of_stock', 'Out of Stock')
    ], string='State', default='available')
