from odoo import http
from odoo.http import request


class LibraryController(http.Controller):

    @http.route(
        '/api/library/books',
        type='json',
        auth='public'
    )
    def api_books(self):

        books = request.env[
            'library.book'
        ].sudo().search([
            ('state','=','available')
        ])

        result=[]

        for book in books:

            result.append({

                'id':book.id,
                'name':book.name,
                'author':book.author,
                'quantity':book.quantity

            })

        return result


    @http.route(
        '/api/library/borrow',
        type='json',
        auth='public'
    )
    def api_borrow(
            self,
            name,
            email,
            phone,
            book_id
    ):

        book=request.env[
            'library.book'
        ].sudo().browse(book_id)


        if not book.exists():

            return {
                'success':False,
                'error':'Book not found'
            }


        if book.quantity<=0:

            return {
                'success':False,
                'error':'Out of stock'
            }


        borrow=request.env[
            'library.borrow.request'
        ].sudo().create({

            'name':name,
            'email':email,
            'phone':phone,
            'book_id':book_id

        })


        return {

            'success':True,
            'request_id':borrow.id

        }


    @http.route(
        '/api/library/my-requests',
        type='json',
        auth='user'
    )
    def my_requests(self):

        email=request.env.user.email


        requests=request.env[
            'library.borrow.request'
        ].sudo().search([

            ('email','=',email)

        ])


        result=[]


        for r in requests:

            result.append({

                'id':r.id,
                'name':r.name,
                'book':r.book_id.name,
                'state':r.state

            })


        return result